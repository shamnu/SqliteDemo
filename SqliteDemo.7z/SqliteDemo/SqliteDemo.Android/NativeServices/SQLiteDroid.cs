﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using SQLite;
using SqliteDemo.Droid.NativeServices;
using SqliteDemo.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using static System.Environment;

[assembly: Xamarin.Forms.Dependency(typeof(SQLiteDroid))]
namespace SqliteDemo.Droid.NativeServices
{
    internal class SQLiteDroid : ISqlLite
    {
        public SQLiteAsyncConnection GetConnection()
        {
            try
            {
                var dbname = "SqliteDemo.db3";
                var path = Path.Combine(GetFolderPath(SpecialFolder.Personal), dbname);
                return new SQLiteAsyncConnection(path);
            }
            catch (Exception ex)
            {

                System.Diagnostics.Debug.WriteLine(ex.Message);
                return null;
            }
           
        }
    }
}