﻿using SqliteDemo.Services;
using SqliteDemo.Views;
using System;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace SqliteDemo
{
    public partial class App : Application
    {
         
        public App()
        {
            InitializeComponent();

            RegisterDependencyService();
             MainPage = new AppShell();
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
        /// <summary>
        /// registering all services here 
        /// </summary>
        private void RegisterDependencyService()
        { 
            DependencyService.Register<UserService>();  

        }
    }
}
