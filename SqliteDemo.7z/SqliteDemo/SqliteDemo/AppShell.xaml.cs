﻿using SqliteDemo.ViewModels;
using SqliteDemo.Views;
using System;
using System.Collections.Generic;
using Xamarin.Forms;

namespace SqliteDemo
{
    public partial class AppShell : Xamarin.Forms.Shell
    {
        public AppShell()
        {
            InitializeComponent();
            Routing.RegisterRoute(nameof(RegisterUserPage), typeof(RegisterUserPage));
            Routing.RegisterRoute(nameof(DispalyUserPage), typeof(DispalyUserPage));
        }

    }
}
