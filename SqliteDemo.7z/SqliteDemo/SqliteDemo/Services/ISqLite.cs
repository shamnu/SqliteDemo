﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace SqliteDemo.Services
{
    public interface ISqlLite
    {
        SQLiteAsyncConnection GetConnection();
    }
}
