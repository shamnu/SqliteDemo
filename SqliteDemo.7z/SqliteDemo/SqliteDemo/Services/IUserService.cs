﻿using SqliteDemo.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SqliteDemo.Services
{
    public interface IUserService
    {
        Task<List<PersonalDataModel>> GetAllUserAsync();

        Task <bool> SaveUsersAsync(PersonalDataModel Data);
    }
}
