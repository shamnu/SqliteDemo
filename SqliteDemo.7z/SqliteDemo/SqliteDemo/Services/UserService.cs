﻿using SQLite;
using SqliteDemo.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace SqliteDemo.Services
{
    public class UserService : IUserService
    {
        private readonly SQLite.SQLiteAsyncConnection _sqlconnection;
        public UserService()
        {
            _sqlconnection = DependencyService.Get<ISqlLite>().GetConnection();

            _sqlconnection.CreateTableAsync<PersonalDataModel>().Wait();

        }
        /// <summary>
        /// Helps to get all user details 
        /// </summary>
        /// <returns></returns>
        public async Task<List<PersonalDataModel>> GetAllUserAsync()
        {

            try
            {
                if (!TableExists(nameof(PersonalDataModel), _sqlconnection))
                {
                    await _sqlconnection.CreateTableAsync<PersonalDataModel>().ConfigureAwait(false);
                }

                var entities = await _sqlconnection.Table<PersonalDataModel>().ToListAsync().ConfigureAwait(false);
                return entities;
            }
            catch
            {
                return new List<PersonalDataModel>();
            }
        }
        /// <summary>
        /// Help us to save the user details 
        /// </summary>
        /// <param name="Data"></param>
        /// <returns></returns>
        public async Task<bool> SaveUsersAsync(PersonalDataModel Data)
        {
            try
            {
                var tableExists = TableExists(nameof(PersonalDataModel), _sqlconnection);
                if (!tableExists)
                {
                    await _sqlconnection.CreateTableAsync<PersonalDataModel>().ConfigureAwait(false);
                }

                await _sqlconnection.InsertAsync(Data).ConfigureAwait(false);
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }

            return false;
        }

        /// <summary>
        /// helps find the data which we are inserting is duplicate 
        /// </summary>
        /// <param name="currentdata"></param>
        /// <returns></returns>
        public async Task<PersonalDataModel> FindDuplicate(PersonalDataModel currentdata)
        {
            try
            {
                var tableExists = TableExists(nameof(PersonalDataModel), _sqlconnection);
                if (tableExists)
                {
                    return await _sqlconnection.Table<PersonalDataModel>().Where(i => i.Id == currentdata.Id).FirstOrDefaultAsync().ConfigureAwait(false);
                }
                else
                {
                    await _sqlconnection.CreateTableAsync<PersonalDataModel>().ConfigureAwait(false);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }

            return null;
        }

        /// <summary>
        /// helps to chek the table exist or not
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="connection"></param>
        /// <returns></returns>
        private static bool TableExists(string tableName, SQLiteAsyncConnection connection)
        {
            TableMapping map = new TableMapping(typeof(SqlDbType));
            object[] ps = Array.Empty<object>();
            if (connection != null)
            {
                var tableCount = connection.QueryAsync(map, "SELECT * FROM sqlite_master WHERE type = 'table' AND name = '" + tableName + "'", ps).Result.Count; // Executes the query from which we can count the results

                if (tableCount == 0)
                {
                    return false;
                }

                if (tableCount == 1)
                {
                    return true;
                }

                throw new Exception("More than one table by the name of " + tableName + " exists in the database.", null);
            }

            return false;
        }
    }
}
