﻿using SqliteDemo.Models;
using SqliteDemo.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace SqliteDemo.ViewModels
{
    public class DispalyUserViewModel :BaseViewModel
    {
        #region Private Property 
        private Command _pageAppearingCommand;
        private ObservableCollection<PersonalDataModel> _userDataList;
        #endregion

        #region DI
        public IUserService userService => DependencyService.Get<IUserService>();
        #endregion

        #region public Property

        public ObservableCollection<PersonalDataModel> UserDataList
        {
            get => _userDataList;
            set => SetProperty(ref _userDataList, value);
        }
        #endregion

        #region Command

        public ICommand PageAppearingCommand
        {
            get
            {
                if (_pageAppearingCommand == null)
                {
                    _pageAppearingCommand = new Command(PageAppearing);
                }

                return _pageAppearingCommand;
            }
        }
        #endregion

        #region Method

        private async void PageAppearing()
        {
            try
            {
                var data = await userService.GetAllUserAsync().ConfigureAwait(false);
                UserDataList = new ObservableCollection<PersonalDataModel>(data);
            }
            catch (Exception ex)
            {

                Debug.WriteLine(ex.StackTrace);
            }

        }
        #endregion
    }
}
    
