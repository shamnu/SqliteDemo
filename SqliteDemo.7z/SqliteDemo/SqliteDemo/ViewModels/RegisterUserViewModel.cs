﻿using SqliteDemo.Models;
using SqliteDemo.Services;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace SqliteDemo.ViewModels
{
    public class RegisterUserViewModel :BaseViewModel
    {
        #region Private Property 
        private PersonalDataModel _user = new PersonalDataModel();
        private Command _saveUserCommand; 
        private DateTime _dob;
        private Command _pageAppearingCommand;
        #endregion

        #region DI
        public IUserService userService => DependencyService.Get<IUserService>();
        #endregion

        #region Public Property
        public DateTime Dob
        {
            get => _dob;
            set => SetProperty(ref _dob, value);
        }
        public PersonalDataModel User
        {
            get => _user;
            set => SetProperty(ref _user, value);
        }
        #endregion

        #region Command
        public ICommand SaveUserCommand
        {
            get
            {
                if (_saveUserCommand == null)
                {
                    _saveUserCommand = new Command(SaveUser);
                }

                return _saveUserCommand;
            }
        }

        public ICommand PageAppearingCommand
        {
            get
            {
                if (_pageAppearingCommand == null)
                {
                    _pageAppearingCommand = new Command(PageAppearing);
                }

                return _pageAppearingCommand;
            }
        }
        #endregion

        #region Method

        private void PageAppearing()
        {
            try
            {
                Dob = DateTime.Now.Date;
            }
            catch (Exception ex)
            {

                Debug.WriteLine(ex.StackTrace);
            }
            
        }

        /// <summary>
        /// Save data to Sql lite 
        /// </summary>
        /// <param name="obj"></param>
        /// <exception cref="NotImplementedException"></exception>
        private async void SaveUser(object obj)
        {
            try
            {
                if (User != null)
                { 
                    User.Age = CalculatAge(Dob);
                    await userService.SaveUsersAsync(User).ConfigureAwait(false);
                    Device.BeginInvokeOnMainThread(async () =>
                    {
                        try
                        {
                            await Application.Current.MainPage.DisplayAlert("Success", "User Added ", "OK");
                        }
                        catch (Exception e)
                        {

                        }
                    });  
                }
                else
                {
                    return;
                }
            }
            catch (Exception ex)
            {

                Debug.WriteLine(ex.StackTrace);
            }

        }
        /// <summary>
        /// calculate Age according to the dob given by user 
        /// </summary>
        /// <param name="Dob"></param>
        /// <returns></returns>
        /// TODO --- validation to the date time picker need to be added 
        static int CalculatAge(DateTime Dob)
        {
            int age = 0;
            age = DateTime.Now.Year - Dob.Year;
            if (DateTime.Now.DayOfYear < Dob.DayOfYear)
                age = age - 1;

            return age;
        }
            #endregion
        }
}
